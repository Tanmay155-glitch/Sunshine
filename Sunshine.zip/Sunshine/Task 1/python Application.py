#pip install gspread oauth2client
import gspread
from oauth2client.service_account import ServiceAccountCredentials
import threading
import time

# Setup Google Sheets connection
scope = ['https://spreadsheets.google.com/feeds', 'https://www.googleapis.com/auth/drive']
creds = ServiceAccountCredentials.from_json_keyfile_name('credentials.json', scope)
client = gspread.authorize(creds)
sheet = client.open("InternshipSheet").sheet1  # Replace with your sheet name

# Event to restart thread1
restart_event = threading.Event()

# Thread 1: Sends data to A3
def write_data():
    while not restart_event.is_set():
        current_time = time.strftime("%H:%M:%S")
        sheet.update_acell('A3', f"Updated at {current_time}")
        print(f"Thread 1: Sent data at {current_time}")
        time.sleep(5)

# Thread 2: Checks A5 and restarts Thread 1 if needed
def monitor_a5():
    global t1
    while True:
        a5_value = sheet.acell('A5').value
        print(f"Thread 2: Read A5 = {a5_value}")
        if a5_value == "1":
            print("Restarting Thread 1...")
            restart_event.set()
            t1.join()
            restart_event.clear()
            sheet.update_acell('A5', "0")  # Reset trigger
            t1 = threading.Thread(target=write_data)
            t1.start()
        time.sleep(3)

# Initialize threads
t1 = threading.Thread(target=write_data)
t2 = threading.Thread(target=monitor_a5)

# Start threads
t1.start()
t2.start()
