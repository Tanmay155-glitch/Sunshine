#include <stdio.h>
#include <time.h>
#include <unistd.h>

int main() {
    char choice;
    time_t start, end;
    double total_hours = 0.0;

    while (1) {
        printf("\nPress 's' to START work, 'e' to END work, 'q' to quit: ");
        scanf(" %c", &choice);

        if (choice == 's') {
            time(&start);
            printf("Work started at %s", ctime(&start));
        } 
        else if (choice == 'e') {
            time(&end);
            printf("Work ended at %s", ctime(&end));
            double session = difftime(end, start) / 3600.0;
            total_hours += session;
            printf("Session duration: %.2f hours\n", session);
            printf("Total working hours so far: %.2f\n", total_hours);
        } 
        else if (choice == 'q') {
            printf("Final total hours worked: %.2f\n", total_hours);
            break;
        } 
        else {
            printf("Invalid input!\n");
        }
    }

    return 0;
}
