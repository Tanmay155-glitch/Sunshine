#include <WiFi.h>
#include <HTTPClient.h>

const char* ssid = "YOUR_WIFI";
const char* password = "YOUR_PASS";
const int fanPin = 5;

void setup() {
  pinMode(fanPin, OUTPUT);
  Serial.begin(115200);
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) delay(1000);
}

void loop() {
  HTTPClient http;
  http.begin("https://script.google.com/macros/s/YOUR_SCRIPT_ID/exec?action=read");
  int code = http.GET();
  if (code == 200) {
    float temp = http.getString().toFloat();
    digitalWrite(fanPin, temp >= 35 ? HIGH : LOW);
    Serial.println("Temp: " + String(temp) + " Fan: " + (temp >= 35 ? "ON" : "OFF"));
  }
  http.end();
  delay(10000);
}
