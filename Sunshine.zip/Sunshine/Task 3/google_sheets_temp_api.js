var sheet = SpreadsheetApp.openById("YOUR_SHEET_ID").getSheetByName("Sheet1");

function doGet(e) {
  var action = e.parameter.action;
  if (action == "write") {
    sheet.getRange("A1").setValue(e.parameter.temp);
    return ContentService.createTextOutput("Temperature updated");
  } 
  if (action == "read") {
    var temp = sheet.getRange("A1").getValue();
    return ContentService.createTextOutput(temp);
  }
}
