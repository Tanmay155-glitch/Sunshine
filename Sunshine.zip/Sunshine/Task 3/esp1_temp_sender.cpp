#include <WiFi.h>
#include <HTTPClient.h>
#include "DHT.h"

#define DHTPIN 4
#define DHTTYPE DHT11

DHT dht(DHTPIN, DHTTYPE);
const char* ssid = "YOUR_WIFI";
const char* password = "YOUR_PASS";

void setup() {
  Serial.begin(115200);
  WiFi.begin(ssid, password);
  dht.begin();
  while (WiFi.status() != WL_CONNECTED) delay(1000);
}

void loop() {
  float temp = dht.readTemperature();
  if (!isnan(temp)) {
    HTTPClient http;
    String url = "https://script.google.com/macros/s/YOUR_SCRIPT_ID/exec?action=write&temp=" + String(temp);
    http.begin(url);
    http.GET();
    http.end();
    Serial.println("Temp sent: " + String(temp));
  }
  delay(10000);
}
